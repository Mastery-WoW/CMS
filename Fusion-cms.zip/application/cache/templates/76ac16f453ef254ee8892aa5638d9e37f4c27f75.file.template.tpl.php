<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:28:13
         compiled from "application/themes/blueweb/template.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15562926295150892de0d409-47062793%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '76ac16f453ef254ee8892aa5638d9e37f4c27f75' => 
    array (
      0 => 'application/themes/blueweb/template.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15562926295150892de0d409-47062793',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'head' => 0,
    'modals' => 0,
    'header_url' => 0,
    'menu_top' => 0,
    'menu_1' => 0,
    'menu_side' => 0,
    'menu_2' => 0,
    'sideboxes' => 0,
    'sidebox' => 0,
    'show_slider' => 0,
    'slider' => 0,
    'image' => 0,
    'page' => 0,
    'serverName' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150892de87793_41404614',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150892de87793_41404614')) {function content_5150892de87793_41404614($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['head']->value;?>

	<body>
		<?php echo $_smarty_tpl->tpl_vars['modals']->value;?>

		<div id="top">
        	
		</div>
		<div id="wrapper">
			<div id="header" <?php echo $_smarty_tpl->tpl_vars['header_url']->value;?>
></div>
			<div id="menu">
				<ul>
					<?php  $_smarty_tpl->tpl_vars['menu_1'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_1']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu_top']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_1']->key => $_smarty_tpl->tpl_vars['menu_1']->value){
$_smarty_tpl->tpl_vars['menu_1']->_loop = true;
?>
						<li><a <?php echo $_smarty_tpl->tpl_vars['menu_1']->value['link'];?>
><?php echo $_smarty_tpl->tpl_vars['menu_1']->value['name'];?>
</a></li>
					<?php } ?>
				</ul>
			</div>
			
			<!-- body start -->
			<div id="body">
            	<div id="space"></div>
                
				<div id="left">
					<div class="left_box">
						<div class="left_box_top">Site menu</div>
						<ul>
                        	<?php  $_smarty_tpl->tpl_vars['menu_2'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_2']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu_side']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_2']->key => $_smarty_tpl->tpl_vars['menu_2']->value){
$_smarty_tpl->tpl_vars['menu_2']->_loop = true;
?>
								<li><a <?php echo $_smarty_tpl->tpl_vars['menu_2']->value['link'];?>
><?php echo $_smarty_tpl->tpl_vars['menu_2']->value['name'];?>
</a></li>
							<?php } ?>
                        </ul>
					</div>
                    
                    <?php  $_smarty_tpl->tpl_vars['sidebox'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['sidebox']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sideboxes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['sidebox']->key => $_smarty_tpl->tpl_vars['sidebox']->value){
$_smarty_tpl->tpl_vars['sidebox']->_loop = true;
?>
                    <div class="left_box">
						<div class="left_box_top"><?php echo $_smarty_tpl->tpl_vars['sidebox']->value['name'];?>
</div>
						<div style="padding:5px;">
								<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['data'];?>

							</div>
					</div>
					<?php } ?>
				</div>
				
				<div id="right">
					<div class="right_box" id="slider_box" <?php if (!$_smarty_tpl->tpl_vars['show_slider']->value){?>style="display:none;"<?php }?>>
						<div id="slider">
							<?php  $_smarty_tpl->tpl_vars['image'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['image']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['slider']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['image']->key => $_smarty_tpl->tpl_vars['image']->value){
$_smarty_tpl->tpl_vars['image']->_loop = true;
?>
								<a href="<?php echo $_smarty_tpl->tpl_vars['image']->value['link'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['image']->value['image'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['image']->value['text'];?>
"/></a>
							<?php } ?>
						</div>
					</div>
					<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

				</div>
                
                <div class="clear"></div>
			</div>
			<!-- body end -->
			
			<div id="footer">
                &copy; Copyright <?php echo date("Y");?>
 <?php echo $_smarty_tpl->tpl_vars['serverName']->value;?>


				<div id="cms">
                	<a href="http://raxezdev.com/fusioncms" target="_blank"></a>
                </div>
            </div>
		</div>
	</body>
</html><?php }} ?>