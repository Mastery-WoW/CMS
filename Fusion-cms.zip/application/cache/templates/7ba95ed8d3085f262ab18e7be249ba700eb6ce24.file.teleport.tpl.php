<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:22:04
         compiled from "application/modules/teleport/views/teleport.tpl" */ ?>
<?php /*%%SmartyHeaderCode:566649628515176cc4c00c4-93094725%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7ba95ed8d3085f262ab18e7be249ba700eb6ce24' => 
    array (
      0 => 'application/modules/teleport/views/teleport.tpl',
      1 => 1360432309,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '566649628515176cc4c00c4-93094725',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'vp' => 0,
    'dp' => 0,
    'total' => 0,
    'characters' => 0,
    'realm' => 0,
    'character' => 0,
    'url' => 0,
    'locations' => 0,
    'location' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515176cc691df5_35444559',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515176cc691df5_35444559')) {function content_515176cc691df5_35444559($_smarty_tpl) {?><script type="text/javascript">
	$(document).ready(function()
	{
		function initializeTeleport()
		{
			if(typeof Teleport != "undefined")
			{
				Teleport.User.initialize(<?php echo $_smarty_tpl->tpl_vars['vp']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['dp']->value;?>
);
			}
			else
			{
				setTimeout(initializeTeleport, 50);
			}
		}

		initializeTeleport();
	});
</script>
<section id="teleport">
	<section id="select_character">
		<div class="online_realm_button"><?php echo lang("select_char","teleport");?>
</div>
		
		<?php if ($_smarty_tpl->tpl_vars['total']->value){?>
			<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['characters']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
				<div class="teleport_realm_divider"><?php echo $_smarty_tpl->tpl_vars['realm']->value['realmName'];?>
</div>
				<?php  $_smarty_tpl->tpl_vars['character'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['character']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realm']->value['characters']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['character']->key => $_smarty_tpl->tpl_vars['character']->value){
$_smarty_tpl->tpl_vars['character']->_loop = true;
?>
					<div class="select_character">
						<div class="character store_item">
							<section class="character_buttons">
								<a href="javascript:void(0)" class="nice_button" onClick="Teleport.selectCharacter(this, <?php echo $_smarty_tpl->tpl_vars['realm']->value['realmId'];?>
, <?php echo $_smarty_tpl->tpl_vars['character']->value['guid'];?>
, '<?php echo $_smarty_tpl->tpl_vars['character']->value['name'];?>
', <?php echo $_smarty_tpl->tpl_vars['character']->value['money']/10000;?>
, '<?php echo $_smarty_tpl->tpl_vars['character']->value['race'];?>
')">
									<?php echo lang("select","teleport");?>

								</a>
							</section>
			
							<img class="item_icon" width="36" height="36" src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/avatars/<?php echo $_smarty_tpl->tpl_vars['character']->value['avatar'];?>
.gif" align="absmiddle" data-tip="<img src='<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/stats/<?php echo $_smarty_tpl->tpl_vars['character']->value['class'];?>
.gif' align='absbottom'/> <?php echo $_smarty_tpl->tpl_vars['character']->value['name'];?>
 (Lv<?php echo $_smarty_tpl->tpl_vars['character']->value['level'];?>
)">
			
							<a class="character_name" data-tip="<img src='<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/stats/<?php echo $_smarty_tpl->tpl_vars['character']->value['class'];?>
.gif' align='absbottom'/> <?php echo $_smarty_tpl->tpl_vars['character']->value['name'];?>
 (Lv<?php echo $_smarty_tpl->tpl_vars['character']->value['level'];?>
)"><?php echo $_smarty_tpl->tpl_vars['character']->value['name'];?>
</a>
							<br /><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle"> <?php echo floor($_smarty_tpl->tpl_vars['character']->value['money']/10000);?>
 <?php echo lang("gold","teleport");?>

							<div class="clear"></div>
						</div>
					</div>
				<?php } ?>
			<?php } ?>
		<?php }else{ ?>
			<center style="padding-top:10px;"><b><?php echo lang("no_chars","teleport");?>
</b></center>
		<?php }?>
	</section>
	<div class="vertical_divider"></div>
	<section id="select_location">
		<?php if ($_smarty_tpl->tpl_vars['locations']->value){?>
			<?php  $_smarty_tpl->tpl_vars['location'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['location']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['locations']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['location']->key => $_smarty_tpl->tpl_vars['location']->value){
$_smarty_tpl->tpl_vars['location']->_loop = true;
?>
				<div class="location" data-realm="<?php echo $_smarty_tpl->tpl_vars['location']->value['realm'];?>
" data-faction="<?php echo $_smarty_tpl->tpl_vars['location']->value['required_faction'];?>
">
					<section class="location_buttons">
						<a href="javascript:void(0)" onClick="Teleport.buy(<?php echo $_smarty_tpl->tpl_vars['location']->value['id'];?>
, this)" class="nice_button">
							<?php if ($_smarty_tpl->tpl_vars['location']->value['vpCost']){?>
								<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/lightning.png" align="absmiddle">
								<?php echo $_smarty_tpl->tpl_vars['location']->value['vpCost'];?>
 <?php echo lang("vp","teleport");?>

							<?php }elseif($_smarty_tpl->tpl_vars['location']->value['dpCost']){?>
								<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle">
								<?php echo $_smarty_tpl->tpl_vars['location']->value['dpCost'];?>
 <?php echo lang("dp","teleport");?>

							<?php }elseif($_smarty_tpl->tpl_vars['location']->value['goldCost']){?>
								<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/icons/coins.png" align="absmiddle">
								<?php echo $_smarty_tpl->tpl_vars['location']->value['goldCost'];?>
 <?php echo lang("gold","teleport");?>

							<?php }else{ ?>
								<?php echo lang("free","teleport");?>

							<?php }?>
						</a>
					</section>

					<a class="location_name"><?php echo $_smarty_tpl->tpl_vars['location']->value['name'];?>
</a>
					<br /><?php echo $_smarty_tpl->tpl_vars['location']->value['description'];?>

					<div class="clear"></div>
				</div>
			<?php } ?>
		<?php }else{ ?>
			<center style="padding-top:10px;"><b><?php echo lang("no_locations","teleport");?>
</b></center>
		<?php }?>
	</section>

	<div class="clear"></div>
</section><?php }} ?>