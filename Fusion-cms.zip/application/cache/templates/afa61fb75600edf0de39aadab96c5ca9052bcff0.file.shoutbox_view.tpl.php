<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:28:03
         compiled from "application/modules/sidebox_shoutbox/views/shoutbox_view.tpl" */ ?>
<?php /*%%SmartyHeaderCode:38636157851508923181db8-33547934%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'afa61fb75600edf0de39aadab96c5ca9052bcff0' => 
    array (
      0 => 'application/modules/sidebox_shoutbox/views/shoutbox_view.tpl',
      1 => 1362831933,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '38636157851508923181db8-33547934',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'count' => 0,
    'shoutsPerPage' => 0,
    'logged_in' => 0,
    'shouts' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51508923221755_70337739',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51508923221755_70337739')) {function content_51508923221755_70337739($_smarty_tpl) {?><script type="text/javascript">
	var shoutCount = <?php echo $_smarty_tpl->tpl_vars['count']->value;?>
,
		shoutsPerPage = <?php echo $_smarty_tpl->tpl_vars['shoutsPerPage']->value;?>
,
		currentShout = 0;

	var extraLanguage = {};

	extraLanguage.ago = "<?php echo lang('ago','sidebox_shoutbox');?>
";
	extraLanguage.view_profile = "<?php echo lang('view_profile','sidebox_shoutbox');?>
";
	extraLanguage.said = "<?php echo lang('said','sidebox_shoutbox');?>
";
	extraLanguage.message_limit = "<?php echo lang('message_limit','sidebox_shoutbox');?>
";

	var isStaff = <?php if (hasPermission("shoutAsStaff","sidebox_shoutbox")){?>true<?php }else{ ?>false<?php }?>;

	
	var Shoutbox = {

		/**
		 * Load more shouts
		 * @param number
		 */
		load: function(number)
		{
			var element = $("#the_shouts");

			currentShout = number;

			element.slideUp(500, function()
			{
				$.get(Config.URL + "sidebox_shoutbox/shoutbox/get/" + number, function(data)
				{
					element.html(data).slideDown(300);

					if(currentShout != 0)
					{
						$("#shoutbox_newer").show();
					}
					else
					{
						$("#shoutbox_newer").hide();
					}

					if(currentShout + shoutsPerPage >= shoutCount)
					{
						$("#shoutbox_older").hide();
					}
					else
					{
						$("#shoutbox_older").show();
					}

				});
			});
		},

		submit: function()
		{
			var message = $("#shoutbox_content");

			if(message.val().length == 0
			|| message.val().length > 255)
			{
				UI.alert(extraLanguage.message_limit);
			}
			else
			{
				// Disable fields
				message.attr("disabled", "disabled");
				$("#shoutbox_submit").attr("disabled", "disabled");

				$.post(Config.URL + "sidebox_shoutbox/shoutbox/submit", {message: message.val(), csrf_token_name: Config.CSRF}, function(data)
				{
					message.val("");
					message.removeAttr("disabled");
					$("#shoutbox_submit").removeAttr("disabled");
					$("#shoutbox_characters_remaining").html("0 / 255");

					var content = JSON.parse(data);
					
					var staff = (isStaff) ? '<img src="' + Config.URL + 'application/images/icons/icon_blizzard.gif" align="absmiddle"/>&nbsp;': '';

					$("#the_shouts").prepend('<div class="shout" id="my_shout_' + content.uniqueId + '" style="display:none">'+
												'<span class="shout_date">' + content.time + ' ' + extraLanguage.ago + '</span>' +
												'<div class="shout_author">' + staff + '<a href="' + Config.URL + 'profile/' + content.id + '" data-tip="' + extraLanguage.view_profile + '">' + content.name + '</a> ' + extraLanguage.said + ':</div>' +
												content.message +
											'</div>');

					$("#my_shout_" + content.uniqueId).slideDown(300, function()
					{
						Tooltip.refresh();
					});
				});
			}
		},

		remove: function(field, id)
		{
			$(field).parent().parent().slideUp(150, function()
			{
				$(this).remove();
			});
			
			$.get(Config.URL + "sidebox_shoutbox/shoutbox/delete/" + id, function(data)
			{
				console.log(data);
			});
		}
	};
	
</script>

<div id="shoutbox">
<?php if ($_smarty_tpl->tpl_vars['logged_in']->value==false||!hasPermission("shout","sidebox_shoutbox")){?>
	<form onSubmit="UI.alert('<?php echo lang("log_in","sidebox_shoutbox");?>
');return false;">
		<textarea name="shoutbox_content" placeholder="<?php echo lang("log_in","sidebox_shoutbox");?>
" disabled="disabled"></textarea>
		<div class="shout_characters_remaining"><span id="shoutbox_characters_remaining">0 / 255</span></div>
		<input type="submit" id="shoutbox_submit" value="<?php echo lang("submit","sidebox_shoutbox");?>
"/>
	</form>
<?php }else{ ?>
	<form onSubmit="Shoutbox.submit(); return false">
		<textarea
			id="shoutbox_content"
			placeholder="<?php echo lang("enter","sidebox_shoutbox");?>
"
			onFocus="this.style.height='70px';"
			onBlur="this.style.height='16px'"
			onkeyup="UI.limitCharacters(this, 'shoutbox_characters_remaining')"
			maxlength="255"
			spellcheck="false"></textarea>
		<div class="shout_characters_remaining"><span id="shoutbox_characters_remaining">0 / 255</span></div>
		<input type="submit" name="shoutbox_submit" value="<?php echo lang("submit","sidebox_shoutbox");?>
" />
	</form>
<?php }?>

<div id="the_shouts"><?php echo $_smarty_tpl->tpl_vars['shouts']->value;?>
</div>

<?php if ($_smarty_tpl->tpl_vars['count']->value>5){?>
	<div id="shoutbox_view">
		<a href="javascript:void(0)" onClick="Shoutbox.load(currentShout - shoutsPerPage)" id="shoutbox_newer" style="display:none;">&larr; Newer</a>&nbsp;
		&nbsp;<a href="javascript:void(0)" onClick="Shoutbox.load(currentShout + shoutsPerPage)" id="shoutbox_older">Older &rarr;</a>
	</div>
<?php }?>
</div><?php }} ?>