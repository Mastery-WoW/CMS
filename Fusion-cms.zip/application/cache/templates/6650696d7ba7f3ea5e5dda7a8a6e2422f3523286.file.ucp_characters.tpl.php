<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 10:39:18
         compiled from "application/modules/profile/views/ucp_characters.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24632287651516cc6644274-83809940%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6650696d7ba7f3ea5e5dda7a8a6e2422f3523286' => 
    array (
      0 => 'application/modules/profile/views/ucp_characters.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24632287651516cc6644274-83809940',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'characters' => 0,
    'realms' => 0,
    'id' => 0,
    'realm' => 0,
    'url' => 0,
    'character' => 0,
    'realmsObj' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51516cc66b9874_23577361',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51516cc66b9874_23577361')) {function content_51516cc66b9874_23577361($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['characters']->value>0){?>
<div class="ucp_divider"></div>
<section id="ucp_characters">
	<?php  $_smarty_tpl->tpl_vars['realm'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['realm']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realms']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['realm']->key => $_smarty_tpl->tpl_vars['realm']->value){
$_smarty_tpl->tpl_vars['realm']->_loop = true;
?>
		<?php if ($_smarty_tpl->tpl_vars['realm']->value->getCharacterCount($_smarty_tpl->tpl_vars['id']->value)>0){?>
			<h1><?php echo $_smarty_tpl->tpl_vars['realm']->value->getName();?>
</h1>
			<?php  $_smarty_tpl->tpl_vars['character'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['character']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['realm']->value->getCharacters()->getCharactersByAccount($_smarty_tpl->tpl_vars['id']->value); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['character']->key => $_smarty_tpl->tpl_vars['character']->value){
$_smarty_tpl->tpl_vars['character']->_loop = true;
?>
				<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
character/<?php echo $_smarty_tpl->tpl_vars['realm']->value->getId();?>
/<?php echo $_smarty_tpl->tpl_vars['character']->value['name'];?>
" data-tip="<img src='<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/stats/<?php echo $_smarty_tpl->tpl_vars['character']->value['class'];?>
.gif' align='absbottom'/>&nbsp;&nbsp;<?php echo $_smarty_tpl->tpl_vars['character']->value['name'];?>
">
					<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/avatars/<?php echo $_smarty_tpl->tpl_vars['realmsObj']->value->formatAvatarPath($_smarty_tpl->tpl_vars['character']->value);?>
.gif" />
				</a>
			<?php } ?>
		<?php }?>
	<?php } ?>
	<div class="clear"></div>
</section>
<?php }?><?php }} ?>