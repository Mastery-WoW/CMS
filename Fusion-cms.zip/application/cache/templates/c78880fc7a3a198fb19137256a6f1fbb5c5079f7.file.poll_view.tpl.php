<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:20:26
         compiled from "application/modules/sidebox_poll/views/poll_view.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19637115585151766a884a41-94582616%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c78880fc7a3a198fb19137256a6f1fbb5c5079f7' => 
    array (
      0 => 'application/modules/sidebox_poll/views/poll_view.tpl',
      1 => 1360083929,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19637115585151766a884a41-94582616',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'poll' => 0,
    'total' => 0,
    'myVote' => 0,
    'answer' => 0,
    'online' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5151766a9b4a31_22885843',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5151766a9b4a31_22885843')) {function content_5151766a9b4a31_22885843($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['poll']->value){?>
	<script type="text/javascript">
		var pollTotal = <?php echo $_smarty_tpl->tpl_vars['total']->value;?>
;

		var show_results = "<?php echo lang("show_results","sidebox_poll");?>
";
		var show_options = "<?php echo lang("show_options","sidebox_poll");?>
";

		
			var Poll = {

				toggle: function(field)
				{
					if($("#poll_results").is(":visible"))
					{
						$("#poll_results").slideUp(300, function()
						{
							$(field).html(show_results);
							$("#poll_answers").slideDown(300);
						});
					}
					else
					{
						$("#poll_answers").slideUp(300, function()
						{
							$(field).html(show_options);
							$("#poll_results").slideDown(300);
						});
					}
				},

				vote: function(questionid, id, element)
				{
					if(element.checked)
					{
						$("#poll_actions").fadeOut(150, function()
						{
							$(this).remove();
						});

						$("#poll_answers").fadeOut(300, function()
						{
							$(this).html("<center><img src='" + Config.image_path + "ajax.gif' /></center>").fadeIn(150, function()
							{
								$.post(Config.URL + "sidebox_poll/poll/vote/" + questionid + "/" + id, {csrf_token_name: Config.CSRF}, function(data)
								{
									$("#poll_option_" + id +"_votes").html(parseInt($("#poll_option_" + id +"_votes").html()) + 1);

									$("#poll_answers").fadeOut(150, function()
									{
										$("#poll_results").fadeIn(300, function()
										{
											var percent;
											pollTotal++;

											$(".poll_answer").each(function()
											{
												if(parseInt($(this).find(".poll_votes_count").html()) == 0)
												{
													percent = 0;
												}
												else
												{
													percent = (parseInt($(this).find(".poll_votes_count").html()) / (pollTotal)) * 100;

													if(percent > 99)
													{
														percent = 99;
													}
												}

												$(this).find(".poll_bar_fill").animate({width:percent + "%"}, 300);
											});
										});
									});
								});
							});
						});
					}
				}
			};
		
	</script>

	<div class="poll_question"><?php echo $_smarty_tpl->tpl_vars['poll']->value['question'];?>
</div>

	<?php if ($_smarty_tpl->tpl_vars['poll']->value['answers']){?>

		<?php if (!$_smarty_tpl->tpl_vars['myVote']->value){?>
			<div id="poll_answers">
				<?php  $_smarty_tpl->tpl_vars['answer'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['answer']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['poll']->value['answers']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['answer']->key => $_smarty_tpl->tpl_vars['answer']->value){
$_smarty_tpl->tpl_vars['answer']->_loop = true;
?>
					<div class="poll_answer">
						<label for="poll_option_<?php echo $_smarty_tpl->tpl_vars['answer']->value['answerid'];?>
">
							<input type="radio" name="poll_options" id="poll_option_<?php echo $_smarty_tpl->tpl_vars['answer']->value['answerid'];?>
" <?php if ($_smarty_tpl->tpl_vars['online']->value){?>onChange="Poll.vote(<?php echo $_smarty_tpl->tpl_vars['answer']->value['questionid'];?>
, <?php echo $_smarty_tpl->tpl_vars['answer']->value['answerid'];?>
, this)"<?php }else{ ?>onClick="UI.alert('<?php echo lang("log_in","sidebox_poll");?>
')"<?php }?>/>
							<?php echo $_smarty_tpl->tpl_vars['answer']->value['answer'];?>

					</label>
					</div>
				<?php } ?>
			</div>
		<?php }?>

		<div id="poll_results" <?php if (!$_smarty_tpl->tpl_vars['myVote']->value){?>style="display:none;"<?php }?>>
			<?php  $_smarty_tpl->tpl_vars['answer'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['answer']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['poll']->value['answers']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['answer']->key => $_smarty_tpl->tpl_vars['answer']->value){
$_smarty_tpl->tpl_vars['answer']->_loop = true;
?>
				<div class="poll_answer">
					<div class="poll_votes_count" id="poll_option_<?php echo $_smarty_tpl->tpl_vars['answer']->value['answerid'];?>
_votes">
						<?php echo $_smarty_tpl->tpl_vars['answer']->value['votes'];?>

					</div>

					<?php if ($_smarty_tpl->tpl_vars['myVote']->value==$_smarty_tpl->tpl_vars['answer']->value['answerid']){?>
						<b><?php echo $_smarty_tpl->tpl_vars['answer']->value['answer'];?>
</b>
					<?php }else{ ?>
						<?php echo $_smarty_tpl->tpl_vars['answer']->value['answer'];?>

					<?php }?>

					<div class="poll_bar">
						<div class="poll_bar_fill" id="poll_option_<?php echo $_smarty_tpl->tpl_vars['answer']->value['answerid'];?>
_bar" style="width:<?php echo $_smarty_tpl->tpl_vars['answer']->value['percent'];?>
%"></div>
					</div>
				</div>
			<?php } ?>
		</div>

		<?php if (!$_smarty_tpl->tpl_vars['myVote']->value){?>
			<a id="poll_actions" class="nice_button" href="javascript:void(0)" onClick="Poll.toggle(this)">
				<?php echo lang("show_results","sidebox_poll");?>

			</a>
			<div style="height:10px"></div>
		<?php }?>
	<?php }else{ ?>
		<center><?php echo lang("no_answers","sidebox_poll");?>
</center>
	<?php }?>
<?php }else{ ?>
	<center<?php echo lang("no_poll","sidebox_poll");?>
</center>
<?php }?><?php }} ?>