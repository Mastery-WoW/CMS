<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:28:13
         compiled from "application/themes/blueweb/views/page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17745874875150892dcb0f75-13663116%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f4e0bcfc0159df6d916c53fbc9d180e9f31a6f29' => 
    array (
      0 => 'application/themes/blueweb/views/page.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17745874875150892dcb0f75-13663116',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'headline' => 0,
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150892dcd2f40_71845862',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150892dcd2f40_71845862')) {function content_5150892dcd2f40_71845862($_smarty_tpl) {?><div class="right_box">
	<a class="right_box_top"><?php echo $_smarty_tpl->tpl_vars['headline']->value;?>
</a>
	<div style="padding:5px;"><?php echo $_smarty_tpl->tpl_vars['content']->value;?>
</div>
</div><?php }} ?>