<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:24:20
         compiled from "application/modules/ucp/views/settings.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1617473289515088442ee767-92987868%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '043c7b3ca7f9f784d8e14fb310ca7219016cb9a3' => 
    array (
      0 => 'application/modules/ucp/views/settings.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1617473289515088442ee767-92987868',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'nickname' => 0,
    'location' => 0,
    'show_language_chooser' => 0,
    'languages' => 0,
    'language' => 0,
    'userLanguage' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150884434a873_15689833',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150884434a873_15689833')) {function content_5150884434a873_15689833($_smarty_tpl) {?><form onSubmit="Settings.submitInfo(); return false" id="settings_info" class="page_form">
	<table style="width:90%">
		<tr>
			<td style="width:25% !important"><label for="nickname_field">Nickname</label></td>
			<td><input type="text" name="nickname_field" id="nickname_field" value="<?php echo $_smarty_tpl->tpl_vars['nickname']->value;?>
"/></td>
		</tr>
		<tr>
			<td style="width:25% !important"><label for="location_field">Location</label></td>
			<td><input type="text" name="location_field" id="location_field" value="<?php echo $_smarty_tpl->tpl_vars['location']->value;?>
"/></td>
		</tr>
		<?php if ($_smarty_tpl->tpl_vars['show_language_chooser']->value){?>
			<tr>
				<td style="width:25% !important"><label for="language_field">Website language</label></td>
				<td>
					<select name="language_field" id="language_field">
						<?php  $_smarty_tpl->tpl_vars['language'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['language']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['language']->key => $_smarty_tpl->tpl_vars['language']->value){
$_smarty_tpl->tpl_vars['language']->_loop = true;
?>
							<option value="<?php echo $_smarty_tpl->tpl_vars['language']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['userLanguage']->value==$_smarty_tpl->tpl_vars['language']->value){?>selected="selected"<?php }?>><?php echo ucfirst($_smarty_tpl->tpl_vars['language']->value);?>
</option>
						<?php } ?>
					</select>
				</td>
			</tr>
		<?php }?>
	</table>

	<center style="margin-bottom:10px;">
		<input type="submit" value="Change information" />
	</center>

	<div id="settings_info_ajax" style="text-align:center;padding:10px;"></div>
</form>
<div class="ucp_divider"></div>
<form onSubmit="Settings.submit(); return false" id="settings" class="page_form">
	<table style="width:90%">
		<tr>
			<td style="width:25% !important"><label for="old_password">Old password</label></td>
			<td><input type="password" name="old_password" id="old_password"/></td>
		</tr>
		<tr>
			<td><label for="new_password">New password</label></td>
			<td><input type="password" name="new_password" id="new_password"/></td>
		</tr>
		<tr>
			<td><label for="new_password_confirm">Confirm password</label></td>
			<td><input type="password" name="new_password_confirm" id="new_password_confirm"/></td>
		</tr>
	</table>

	<center style="margin-bottom:10px;">
		<input type="submit" value="Change password" />
	</center>

	<div id="settings_ajax" style="text-align:center;padding:10px;"></div>
</form><?php }} ?>