<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:18:54
         compiled from "application/modules/vote/views/admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:165428415151760ead2f13-39773693%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f6c471924d6be2df7f97141bd425e42a8213f5f7' => 
    array (
      0 => 'application/modules/vote/views/admin.tpl',
      1 => 1362226845,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '165428415151760ead2f13-39773693',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'topsites' => 0,
    'vote_site' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5151760eb97a98_05036390',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5151760eb97a98_05036390')) {function content_5151760eb97a98_05036390($_smarty_tpl) {?><section class="box big" id="main_topsites">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_list.png"/>
		Topsites (<div style="display:inline;" id="topsites_count"><?php if (!$_smarty_tpl->tpl_vars['topsites']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['topsites']->value);?>
<?php }?></div>)
	</h2>

	<?php if (hasPermission("canCreate")){?>
		<span>
			<a class="nice_button" href="javascript:void(0)" onClick="Topsites.add()">Create topsite</a>
		</span>
	<?php }?>

	<ul id="topsites_list">
		<?php if ($_smarty_tpl->tpl_vars['topsites']->value){?>
			<?php  $_smarty_tpl->tpl_vars['vote_site'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vote_site']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['topsites']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vote_site']->key => $_smarty_tpl->tpl_vars['vote_site']->value){
$_smarty_tpl->tpl_vars['vote_site']->_loop = true;
?>
				<li>
					<table width="100%">
						<tr>
							<td width="30%"><?php if ($_smarty_tpl->tpl_vars['vote_site']->value['vote_image']){?><img src="<?php echo $_smarty_tpl->tpl_vars['vote_site']->value['vote_image'];?>
" style="opacity:1;" /><?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['vote_site']->value['vote_sitename'];?>
<?php }?></td>
							<td width="30%"><?php echo $_smarty_tpl->tpl_vars['vote_site']->value['points_per_vote'];?>
 voting point<?php if ($_smarty_tpl->tpl_vars['vote_site']->value['points_per_vote']>1){?>s<?php }?></td>
							<td width="30%"><?php echo $_smarty_tpl->tpl_vars['vote_site']->value['hour_interval'];?>
 hours</td>
							<td style="text-align:right;">
								<?php if (hasPermission("canEdit")){?>
								<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
vote/admin/edit/<?php echo $_smarty_tpl->tpl_vars['vote_site']->value['id'];?>
" data-tip="Edit"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
								<?php }?>

								<?php if (hasPermission("canDelete")){?>
								<a href="javascript:void(0)" onClick="Topsites.remove(<?php echo $_smarty_tpl->tpl_vars['vote_site']->value['id'];?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
								<?php }?>
							</td>
						</tr>
					</table>
				</li>
			<?php } ?>
		<?php }?>
	</ul>
</section>

<section class="box big" id="add_topsites" style="display:none;">
	<h2><a href='javascript:void(0)' onClick="Topsites.add()" data-tip="Return to topsites">Topsites</a> &rarr; New topsite</h2>

	<form onSubmit="Topsites.create(this); return false" id="submit_form">

		<label for="vote_sitename">Site name</label>
		<input type="text" name="vote_sitename" id="vote_sitename"/>

		<label for="vote_url">Site URL</label>
		<input type="text" name="vote_url" id="vote_url" placeholder="http://" onChange="Topsites.check(this)"/>

		<label for="vote_image">Vote site image (will be auto-completed if URL is recognized)</label>
		<input type="text" name="vote_image" id="vote_image" placeholder="(optional)"/>

		<label for="hour_interval">Hour interval</label>
		<input type="text" name="hour_interval" id="hour_interval" value="12"/>

		<label for="points_per_vote">Voting points</label>
		<input type="text" name="points_per_vote" id="points_per_vote" value="1"/>

		<div id="api" style="display:none;">
			<label for="api_enabled">Enable postback (only some topsites support this - requires additional configuration on the topsite itself)</label>
			<select id="api_enabled" name="api_enabled">
				<option value="0" selected>No</option>
				<option value="1">Yes</option>
			</select>
		</div>

		<input type="submit" value="Submit topsite" />
	</form>
</section><?php }} ?>