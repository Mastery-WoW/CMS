<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:01:50
         compiled from "application/modules/news/views/admin_edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:158782677651506db71ecf96-70020013%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '373c9d33e82ad812a8aff1341274f2fca5a8f9e9' => 
    array (
      0 => 'application/modules/news/views/admin_edit.tpl',
      1 => 1364230909,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '158782677651506db71ecf96-70020013',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51506db726fe75_00555140',
  'variables' => 
  array (
    'article' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51506db726fe75_00555140')) {function content_51506db726fe75_00555140($_smarty_tpl) {?><?php echo TinyMCE();?>

<section class="box big">
	<h2>Edit article</h2>

	<form onSubmit="News.send(<?php echo $_smarty_tpl->tpl_vars['article']->value['id'];?>
); return false">
		<label for="headline">Headline</label>
		<input type="hidden" id="headline" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['article']->value['headline']);?>
"/>
		
		<label for="news_content">
			Content
		</label>
	</form>
		<div style="padding:10px;">
			<textarea name="news_content" class="tinymce" id="news_content" cols="30" rows="10"><?php echo $_smarty_tpl->tpl_vars['article']->value['content'];?>
</textarea>
		</div>
	<form onSubmit="News.send(<?php echo $_smarty_tpl->tpl_vars['article']->value['id'];?>
); return false">
		<label>Article settings</label>

		<input type="checkbox" id="avatar" <?php if ($_smarty_tpl->tpl_vars['article']->value['avatar']){?>checked="yes"<?php }?> value="1"/>
		<label for="avatar" class="inline_label">Show your avatar</label>

		<input type="checkbox" id="comments" <?php if ($_smarty_tpl->tpl_vars['article']->value['comments']!=-1){?>checked="yes"<?php }?> value="1"/>
		<label for="comments" class="inline_label">Allow comments</label>

		<input type="submit" value="Save article" />
	</form>
</section>

<script>
	require([Config.URL + "application/themes/admin/js/mli.js"], function()
	{
		new MultiLanguageInput($("#headline"));
	});
</script><?php }} ?>