<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:46:00
         compiled from "application/modules/sidebox_status/views/ajax.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1764712397515047082999c0-28924029%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f5dfc9c2760c56440e8a867464bdc09eb5549acd' => 
    array (
      0 => 'application/modules/sidebox_status/views/ajax.tpl',
      1 => 1362830549,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1764712397515047082999c0-28924029',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'image_path' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515047082a3ef1_23653320',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515047082a3ef1_23653320')) {function content_515047082a3ef1_23653320($_smarty_tpl) {?><section id="update_status">
	<div style="text-align:center;margin-top:10px;margin-bottom:10px;">
		<img src="<?php echo $_smarty_tpl->tpl_vars['image_path']->value;?>
ajax.gif" />
	</div>
</section>

<script type="text/javascript">
	var Status = {
		statusField: $("#update_status"),
		
		/**
		 * Refresh the realm status
		 */
		update: function()
		{
			$.get(Config.URL + "sidebox_status/status_refresh", function(data)
			{
				Status.statusField.fadeOut(300, function()
				{
					Status.statusField.html(data);
					Status.statusField.fadeIn(300);
				})
			});
		}
	}

	Status.update();
</script><?php }} ?>