<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:27:08
         compiled from "application/modules/sidebox_language_picker/views/language.tpl" */ ?>
<?php /*%%SmartyHeaderCode:780410462515088ecb11047-19513978%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '483e856221d27880dc9b39c80c9e46f17d412a28' => 
    array (
      0 => 'application/modules/sidebox_language_picker/views/language.tpl',
      1 => 1360617411,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '780410462515088ecb11047-19513978',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'image_path' => 0,
    'languages' => 0,
    'language' => 0,
    'current' => 0,
    'url' => 0,
    'flag' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515088ecb91d75_14316907',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515088ecb91d75_14316907')) {function content_515088ecb91d75_14316907($_smarty_tpl) {?><style type="text/css">
	#language_picker a {
		display:block;
		padding:8px;
		font-size:14px;
		transition:0.3s all;
		-webkit-transition:0.3s all;
		-moz-transition:0.3s all;
		-o-transition:0.3s all;
		-ms-transition:0.3s all;
		border-bottom:1px solid rgba(0,0,0,0.1);
		border-top:1px solid rgba(255,255,255,0.05);
		opacity:0.4;
	}

	#language_picker a:last-child { border-bottom:none; }
	
	#language_picker a:first-child { border-top:none; }

	#language_picker a img {
		margin-right:10px;
	}

	#language_picker a:hover {
		padding-left:20px;
		opacity:1;
	}

	#language_picker .current_language {
		opacity:1;
	}
</style>

<script type="text/javascript">
	function setLanguage(language, field)
	{
		$("#language_picker").fadeOut(250, function()
		{
			$(this).html('<center><img src="<?php echo $_smarty_tpl->tpl_vars['image_path']->value;?>
ajax.gif" /></center>').fadeIn(250, function()
			{
				$.get(Config.URL + "sidebox_language_picker/language_picker/set/" + language, function()
				{
					window.location.reload(true);
				});
			});
		})
	}
</script>

<section id="language_picker">
	<?php  $_smarty_tpl->tpl_vars['language'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['language']->_loop = false;
 $_smarty_tpl->tpl_vars['flag'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['language']->key => $_smarty_tpl->tpl_vars['language']->value){
$_smarty_tpl->tpl_vars['language']->_loop = true;
 $_smarty_tpl->tpl_vars['flag']->value = $_smarty_tpl->tpl_vars['language']->key;
?>
		<a href="javascript:void(0)" onClick="setLanguage('<?php echo $_smarty_tpl->tpl_vars['language']->value;?>
', this)" <?php if ($_smarty_tpl->tpl_vars['current']->value==$_smarty_tpl->tpl_vars['language']->value){?>class="current_language"<?php }?>>
			<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/images/flags/<?php echo $_smarty_tpl->tpl_vars['flag']->value;?>
.png" alt="<?php echo $_smarty_tpl->tpl_vars['flag']->value;?>
"> <?php echo ucfirst($_smarty_tpl->tpl_vars['language']->value);?>

		</a>
	<?php } ?>
</section><?php }} ?>