<?php /* Smarty version Smarty-3.1.8, created on 2013-03-26 11:19:28
         compiled from "application/modules/sidebox_poll/views/admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1300765819515176300ed610-27712309%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '35c59ed146862b3326f2b595fa93e97527e5c59a' => 
    array (
      0 => 'application/modules/sidebox_poll/views/admin.tpl',
      1 => 1363627012,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1300765819515176300ed610-27712309',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'polls' => 0,
    'poll' => 0,
    'answer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515176301a7d18_16525871',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515176301a7d18_16525871')) {function content_515176301a7d18_16525871($_smarty_tpl) {?><section class="box big" id="main_polls">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_graph.png"/>
		Polls (<div style="display:inline;" id="polls_count"><?php if (!$_smarty_tpl->tpl_vars['polls']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['polls']->value);?>
<?php }?></div>)
	</h2>

	<span>
		<a class="nice_button" href="javascript:void(0)" onClick="Poll.add()">Create poll</a>
	</span>

	<ul id="polls_list">
		<?php if ($_smarty_tpl->tpl_vars['polls']->value){?>
			<?php  $_smarty_tpl->tpl_vars['poll'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['poll']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['polls']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['poll']->key => $_smarty_tpl->tpl_vars['poll']->value){
$_smarty_tpl->tpl_vars['poll']->_loop = true;
?>
				<li>
					<table width="100%">
						<tr>
							<td width="80%"><?php if (isset($_smarty_tpl->tpl_vars['poll']->value['active'])){?><span style="padding:0px;display:inline;color:green;">Current:</span> <?php }?><b><?php echo $_smarty_tpl->tpl_vars['poll']->value['question'];?>
</b></td>
							<td style="text-align:right;">
								<a href="javascript:void(0)" onClick="Poll.remove(<?php echo $_smarty_tpl->tpl_vars['poll']->value['questionid'];?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
							</td>
						</tr>
					</table>
					<table width="100%">
						<?php if ($_smarty_tpl->tpl_vars['poll']->value['answers']){?>
							<?php  $_smarty_tpl->tpl_vars['answer'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['answer']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['poll']->value['answers']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['answer']->key => $_smarty_tpl->tpl_vars['answer']->value){
$_smarty_tpl->tpl_vars['answer']->_loop = true;
?>
								<tr>
									<td width="17%" style="padding-left:20px;">
										<b><?php echo $_smarty_tpl->tpl_vars['answer']->value['votes'];?>
 (<?php if ($_smarty_tpl->tpl_vars['answer']->value['votes']!=0&&$_smarty_tpl->tpl_vars['poll']->value['total']!=0){?><?php echo round(($_smarty_tpl->tpl_vars['answer']->value['votes']/$_smarty_tpl->tpl_vars['poll']->value['total'])*100);?>
<?php }else{ ?>0<?php }?>%)</b>
									</td>
									<td>
										<?php echo $_smarty_tpl->tpl_vars['answer']->value['answer'];?>

									</td>
								</tr>
							<?php } ?>
						<?php }?>
					</table>
				</li>
			<?php } ?>
		<?php }?>
	</ul>

	<span>
		<center>To display the poll, please <b><a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/sidebox">create the poll sidebox</a></b></center>
	</span>
</section>

<section class="box big" id="add_polls" style="display:none;">
	<h2><a href='javascript:void(0)' onClick="Poll.add()" data-tip="Return to polls">Polls</a> &rarr; New poll</h2>

	<form onSubmit="Poll.create(this); return false" id="submit_form">

		<label for="question">Question</label>
		<input type="text" name="question" id="question"/>

		<label>Answers (<a href="javascript:void(0)" onClick="Poll.addAnswer()">add more</a>)</label>
		<div id="answer_fields">
			<input type="text" name="answer_1" id="answer_1" placeholder="Answer 1"/>
			<input type="text" name="answer_2" id="answer_2" placeholder="Answer 2"/>
		</div>

		<input type="submit" value="Submit poll" />
	</form>
</section><?php }} ?>