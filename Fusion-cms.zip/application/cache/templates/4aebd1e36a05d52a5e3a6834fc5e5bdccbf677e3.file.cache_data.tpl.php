<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 16:03:49
         compiled from "application/modules/admin/views/cachemanager/cache_data.tpl" */ ?>
<?php /*%%SmartyHeaderCode:940728097515067557ac970-98894892%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4aebd1e36a05d52a5e3a6834fc5e5bdccbf677e3' => 
    array (
      0 => 'application/modules/admin/views/cachemanager/cache_data.tpl',
      1 => 1360148835,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '940728097515067557ac970-98894892',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'item' => 0,
    'website' => 0,
    'message' => 0,
    'total' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150675582df35_35643810',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150675582df35_35643810')) {function content_5150675582df35_35643810($_smarty_tpl) {?><li>
	<table width="100%">
		<tr>
			<td width="50%">Item cache</td>
			<td id="row_item"><?php echo $_smarty_tpl->tpl_vars['item']->value['files'];?>
 files (<?php echo $_smarty_tpl->tpl_vars['item']->value['sizeString'];?>
)</td>
		</tr>
	</table>
</li>

<li>
	<table width="100%">
		<tr>
			<td width="50%">Website cache</td>
			<td id="row_website"><?php echo $_smarty_tpl->tpl_vars['website']->value['files'];?>
 files (<?php echo $_smarty_tpl->tpl_vars['website']->value['sizeString'];?>
)</td>
		</tr>
	</table>
</li>

<li>
	<table width="100%">
		<tr>
			<td width="50%">Private message cache</td>
			<td id="row_message"><?php echo $_smarty_tpl->tpl_vars['message']->value['files'];?>
 files (<?php echo $_smarty_tpl->tpl_vars['message']->value['sizeString'];?>
)</td>
		</tr>
	</table>
</li>

<li>
	<table width="100%">
		<tr>
			<td width="50%"><b>Total</b></td>
			<td id="row_total"><b><?php echo $_smarty_tpl->tpl_vars['total']->value['files'];?>
 files (<?php echo $_smarty_tpl->tpl_vars['total']->value['size'];?>
)</b></td>
		</tr>
	</table>
</li><?php }} ?>