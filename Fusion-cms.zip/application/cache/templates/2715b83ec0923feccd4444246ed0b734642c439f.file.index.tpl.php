<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:47:05
         compiled from "application/modules/admin/views/aclmanager/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1307092693515047499d1133-14861045%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2715b83ec0923feccd4444246ed0b734642c439f' => 
    array (
      0 => 'application/modules/admin/views/aclmanager/index.tpl',
      1 => 1363629788,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1307092693515047499d1133-14861045',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_51504749a06be2_62271255',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_51504749a06be2_62271255')) {function content_51504749a06be2_62271255($_smarty_tpl) {?><section class="box big">

	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_settings.png"/>
		What do you want to manage?
	</h2>

	<span style="padding-top:22px;padding-bottom:22px;">
		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/groups" class="big_icon_button" data-tip="Groups are a set of roles that is assigned to users">
			<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/admin/images/id.png" style="margin-top:-12px;">
			Groups
		</a>

		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/roles" class="big_icon_button" data-tip="A role is a set of permissions that can be assigned to a group">
			<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/admin/images/eye.png" style="margin-top:-4px;">
			Roles
		</a>

		<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/accounts" class="big_icon_button" data-tip="Users can be specifically allowed or denied to certain permissions">
			<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/modules/admin/images/man-user.png" style="margin-top:-14px;">
			User permissions
		</a>

		<div class="clear"></div>
	</span>

</section><?php }} ?>