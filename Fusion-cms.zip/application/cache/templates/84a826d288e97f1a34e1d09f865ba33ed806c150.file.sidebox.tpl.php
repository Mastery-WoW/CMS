<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:19:57
         compiled from "application/modules/admin/views/sidebox/sidebox.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20051534515150853b03d084-85631920%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '84a826d288e97f1a34e1d09f865ba33ed806c150' => 
    array (
      0 => 'application/modules/admin/views/sidebox/sidebox.tpl',
      1 => 1364231581,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20051534515150853b03d084-85631920',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150853b0bebb8_12005035',
  'variables' => 
  array (
    'url' => 0,
    'sideboxes' => 0,
    'sidebox' => 0,
    'sideboxModules' => 0,
    'name' => 0,
    'module' => 0,
    'fusionEditor' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150853b0bebb8_12005035')) {function content_5150853b0bebb8_12005035($_smarty_tpl) {?><section class="box big" id="main_sidebox">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_grid.png"/>
		Sideboxes (<div style="display:inline;" id="sidebox_count"><?php if (!$_smarty_tpl->tpl_vars['sideboxes']->value){?>0<?php }else{ ?><?php echo count($_smarty_tpl->tpl_vars['sideboxes']->value);?>
<?php }?></div>)
	</h2>

	<span>
		<a class="nice_button" href="javascript:void(0)" onClick="Sidebox.add()">Create sidebox</a>
	</span>

	<ul id="sidebox_list">
		<?php if ($_smarty_tpl->tpl_vars['sideboxes']->value){?>
		<?php  $_smarty_tpl->tpl_vars['sidebox'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['sidebox']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['sideboxes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['sidebox']->key => $_smarty_tpl->tpl_vars['sidebox']->value){
$_smarty_tpl->tpl_vars['sidebox']->_loop = true;
?>
			<li>
				<table width="100%">
					<tr>
						<td width="10%"><a href="javascript:void(0)" onClick="Sidebox.move('up', <?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
, this)" data-tip="Move up"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_up.png" /></a>
							<a href="javascript:void(0)" onClick="Sidebox.move('down', <?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
, this)" data-tip="Move down"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_down.png" /></a></td>
						<td width="20%"><b><?php echo langColumn($_smarty_tpl->tpl_vars['sidebox']->value['displayName']);?>
</b></td>
						<td width="30%"><?php echo $_smarty_tpl->tpl_vars['sidebox']->value['name'];?>
</td>
						<td width="30%"><?php if ($_smarty_tpl->tpl_vars['sidebox']->value['permission']){?>Controlled per group<?php }else{ ?>Visible to everyone<?php }?></td>
						<td style="text-align:right;">
							<a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/sidebox/edit/<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
" data-tip="Edit"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_edit.png" /></a>&nbsp;
							<a href="javascript:void(0)" onClick="Sidebox.remove(<?php echo $_smarty_tpl->tpl_vars['sidebox']->value['id'];?>
, this)" data-tip="Delete"><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_minus.png" /></a>
						</td>
					</tr>
				</table>
			</li>
		<?php } ?>
		<?php }?>
	</ul>
</section>

<section class="box big" id="add_sidebox" style="display:none;">
	<h2><a href='javascript:void(0)' onClick="Sidebox.add()" data-tip="Return to sideboxes">Sideboxes</a> &rarr; New sidebox</h2>

	<form onSubmit="Sidebox.create(this); return false" id="submit_form">
		<label for="displayName">Headline</label>
		<input type="text" name="displayName" id="displayName" />

		<label for="type">Sidebox module</label>
		<select id="type" name="type" onChange="Sidebox.toggleCustom(this)">
			<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['module']->_loop = false;
 $_smarty_tpl->tpl_vars['name'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['sideboxModules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
$_smarty_tpl->tpl_vars['module']->_loop = true;
 $_smarty_tpl->tpl_vars['name']->value = $_smarty_tpl->tpl_vars['module']->key;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['module']->value['name'];?>
</option>
			<?php } ?>
		</select>

		<label for="visibility">Visibility mode</label>
		<select name="visibility" id="visibility" onChange="if(this.value == 'group'){ $('#groups').fadeIn(300); } else { $('#groups').fadeOut(300); }">
			<option value="everyone" selected>Visible to everyone</option>
			<option value="group">Controlled per group</option>
		</select>

		<div style="display:none" id="groups">
			Please manage the group visibility via <a href="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
admin/aclmanager/groups">the group manager</a> once you have created the sidebox
		</div>
	</form>

	<span id="custom_field" style="padding-top:0px;padding-bottom:0px;">
		<label for="text">Content</label>
		<?php echo $_smarty_tpl->tpl_vars['fusionEditor']->value;?>

	</span>

	<form onSubmit="Sidebox.create(document.getElementById('submit_form')); return false">
		<input type="submit" value="Submit sidebox" />
	</form>
</section>

<script>
	require([Config.URL + "application/themes/admin/js/mli.js"], function()
	{
		new MultiLanguageInput($("#displayName"));
	});
</script><?php }} ?>