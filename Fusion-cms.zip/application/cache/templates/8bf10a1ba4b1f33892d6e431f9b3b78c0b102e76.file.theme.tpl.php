<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 18:28:00
         compiled from "application/modules/admin/views/theme.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1199157192515089201a05e9-49762017%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8bf10a1ba4b1f33892d6e431f9b3b78c0b102e76' => 
    array (
      0 => 'application/modules/admin/views/theme.tpl',
      1 => 1360148835,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1199157192515089201a05e9-49762017',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'themes' => 0,
    'manifest' => 0,
    'current_theme' => 0,
    'id' => 0,
    'url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5150892025ca83_63753806',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5150892025ca83_63753806')) {function content_5150892025ca83_63753806($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['manifest'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['manifest']->_loop = false;
 $_smarty_tpl->tpl_vars['id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['themes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['manifest']->key => $_smarty_tpl->tpl_vars['manifest']->value){
$_smarty_tpl->tpl_vars['manifest']->_loop = true;
 $_smarty_tpl->tpl_vars['id']->value = $_smarty_tpl->tpl_vars['manifest']->key;
?>
	<?php if ($_smarty_tpl->tpl_vars['manifest']->value['folderName']==$_smarty_tpl->tpl_vars['current_theme']->value){?>
		<script type="text/javascript">
			
			function checkForTheme()
			{
				if(typeof Theme != "undefined")
				{
					Theme.scroll(<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
);
				}
				else
				{
					setTimeout(checkForTheme, 50);
				}
			}

			checkForTheme();
		</script>
	<?php }?>
<?php } ?>

<div class="statistics" id="theme_list">
	<div id="theme_overflow">
		<?php  $_smarty_tpl->tpl_vars['manifest'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['manifest']->_loop = false;
 $_smarty_tpl->tpl_vars['id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['themes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['manifest']->key => $_smarty_tpl->tpl_vars['manifest']->value){
$_smarty_tpl->tpl_vars['manifest']->_loop = true;
 $_smarty_tpl->tpl_vars['id']->value = $_smarty_tpl->tpl_vars['manifest']->key;
?>
			<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/<?php echo $_smarty_tpl->tpl_vars['manifest']->value['folderName'];?>
/<?php echo $_smarty_tpl->tpl_vars['manifest']->value['screenshot'];?>
" onClick="Theme.scroll(<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
)"/>
		<?php } ?>
		<div class="clear"></div>
	</div>
</div>

<section class="box big" id="theme_list_text">
	<h2><img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/admin/images/icons/black16x16/ic_picture.png"/> Themes</h2>
	<ul>
		<?php  $_smarty_tpl->tpl_vars['manifest'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['manifest']->_loop = false;
 $_smarty_tpl->tpl_vars['id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['themes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['manifest']->key => $_smarty_tpl->tpl_vars['manifest']->value){
$_smarty_tpl->tpl_vars['manifest']->_loop = true;
 $_smarty_tpl->tpl_vars['id']->value = $_smarty_tpl->tpl_vars['manifest']->key;
?>
			<li style="cursor:pointer;" onClick="Theme.scroll(<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
)" id="theme_<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
				<div class="activate_button">
					<?php if ($_smarty_tpl->tpl_vars['manifest']->value['folderName']==$_smarty_tpl->tpl_vars['current_theme']->value){?>
						Current theme
					<?php }else{ ?>
						<a href="javascript:void(0)" onClick="Theme.select('<?php echo strtolower($_smarty_tpl->tpl_vars['manifest']->value['folderName']);?>
')" class="nice_button">Activate theme</a>
					<?php }?>
				</div>

				<img src="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
application/themes/<?php echo strtolower($_smarty_tpl->tpl_vars['manifest']->value['folderName']);?>
/images/<?php echo $_smarty_tpl->tpl_vars['manifest']->value['favicon'];?>
" />
				<b><?php echo $_smarty_tpl->tpl_vars['manifest']->value['name'];?>
</b>
				by 
				<a target="_blank" href="<?php echo $_smarty_tpl->tpl_vars['manifest']->value['website'];?>
"><?php echo $_smarty_tpl->tpl_vars['manifest']->value['author'];?>
</a>
			</li>
		<?php } ?>
	</ul>

	<span>
		<center><b>Want a new look?</b> Get more themes from the <a href="http://fusion.raxezdev.com/themes" target="_blank">FusionHub</a></center>
	</span>
</section><?php }} ?>