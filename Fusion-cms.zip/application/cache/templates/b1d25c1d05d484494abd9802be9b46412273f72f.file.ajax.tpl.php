<?php /* Smarty version Smarty-3.1.8, created on 2013-03-25 13:48:45
         compiled from "application/modules/online/views/ajax.tpl" */ ?>
<?php /*%%SmartyHeaderCode:834151073515047ad4bd961-66031106%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b1d25c1d05d484494abd9802be9b46412273f72f' => 
    array (
      0 => 'application/modules/online/views/ajax.tpl',
      1 => 1359559561,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '834151073515047ad4bd961-66031106',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'image_path' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_515047ad4e2967_40644965',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_515047ad4e2967_40644965')) {function content_515047ad4e2967_40644965($_smarty_tpl) {?><section id="update_online_module">
	<div style="text-align:center;margin-top:10px;margin-bottom:10px;">
		<img src="<?php echo $_smarty_tpl->tpl_vars['image_path']->value;?>
ajax.gif" />
	</div>
</section>

<script type="text/javascript">
	var OnlineModule = {
		field: $("#update_online_module"),
		
		/**
		 * Refresh the realm status
		 */
		update: function()
		{
			$.get(Config.URL + "online/online_refresh", function(data)
			{
				OnlineModule.field.fadeOut(300, function()
				{
					OnlineModule.field.html(data);
					OnlineModule.field.fadeIn(300, function()
					{
						Tooltip.refresh();
					});
				})
			});
		}
	}

	OnlineModule.update();
</script><?php }} ?>